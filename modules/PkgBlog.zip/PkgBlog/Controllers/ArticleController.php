<?php
// Ce fichier est maintenu par ESSARRAJ Fouad


namespace Modules\PkgBlog\Controllers;


use Modules\Core\Controllers\Base\AdminController;
use Modules\PkgBlog\App\Requests\ArticleRequest;
use Modules\PkgBlog\Services\ArticleService;
use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;
use Modules\PkgBlog\App\Exports\ArticleExport;
use Modules\PkgBlog\App\Imports\ArticleImport;

class ArticleController extends AdminController
{
    protected $articleService;

    public function __construct(ArticleService $articleService)
    {
        $this->articleService = $articleService;
    }

    public function index(Request $request)
    {
        // Récupérer la valeur de recherche et paginer
        $searchValue = $request->get('searchValue', '');
        $searchQuery = str_replace(' ', '%', $searchValue);
    
        // Appel de la méthode paginate avec ou sans recherche
        $data = $this->articleService->paginate($searchQuery);
    
        // Gestion AJAX
        if ($request->ajax()) {
            return response()->json([
                'html' => view('PkgBlog::article.table', compact('data'))->render()
            ]);
        }
    
        // Vue principale pour le chargement initial
        return view('PkgBlog::article.index', compact('data'));
    }

    public function create()
    {
        $item = $this->articleService->createInstance();
        return view('PkgBlog::article.create', compact('item'));
    }

    public function store(ArticleRequest $request)
    {
        $validatedData = $request->validated();
        $article = $this->articleService->create($validatedData);
        return redirect()->route('articles.index')->with(
            'success',
            __('Core::msg.addSuccess', [
                'entityToString' => $article,
                'modelName' =>  __('PkgBlog::article.singular')
                ])
        );

    }

    public function show(string $id)
    {
        $item = $this->articleService->find($id);
        return view('PkgBlog::article.show', compact('item'));
    }

    public function edit(string $id)
    {
        $item = $this->articleService->find($id);
        return view('PkgBlog::article.edit', compact('item'));
    }

    public function update(ArticleRequest $request, string $id)
    {
        $validatedData = $request->validated();
        $article = $this->articleService->update($id, $validatedData);
        return redirect()->route('articles.index')->with(
            'success',
            __('Core::msg.updateSuccess', [
                'entityToString' => $article,
                'modelName' =>  __('PkgBlog::article.singular')
                ])
        );
    }

    public function destroy(string $id)
    {
        $article = $this->articleService->destroy($id);
        return redirect()->route('articles.index')->with(
            'success',
            __('Core::msg.deleteSuccess', [
                'entityToString' => $article,
                'modelName' =>  __('PkgBlog::article.singular')
                ])
        );
    }

    public function export()
    {
        $data = $this->articleService->all();
        return Excel::download(new ArticleExport($data), 'article_export.xlsx');
    }
    public function import(Request $request)
    {
        $request->validate([
            'file' => 'required|mimes:xlsx,xls,csv',
        ]);

        try {
            Excel::import(new ArticleImport, $request->file('file'));
        } catch (\InvalidArgumentException $e) {
            return redirect()->route('articles.index')->withError('Invalid format or missing data.');
        }

        return redirect()->route('articles.index')->with(
            'success', __('Core::msg.importSuccess', [
            'modelNames' =>  __('PkgBlog::article.plural')
            ]));



    }
}
