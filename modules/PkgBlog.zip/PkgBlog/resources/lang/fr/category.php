<?php

return [
    'singular' => 'Catégorie',
    'plural' => 'Catégories',
    'name' => 'nom',
    'slug' => 'référence',
];
