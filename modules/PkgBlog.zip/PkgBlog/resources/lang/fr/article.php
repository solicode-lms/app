<?php
// Ce fichier est maintenu par ESSARRAJ Fouad


return [
    'singular' => 'Article',
    'plural' => 'Articles',
    'title' => 'title',
    'slug' => 'slug',
    'content' => 'content',
    'category_id' => 'category_id',
    'user_id' => 'user_id',
];
