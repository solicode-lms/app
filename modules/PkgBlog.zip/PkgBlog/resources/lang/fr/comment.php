<?php
// Ce fichier est maintenu par ESSARRAJ Fouad


return [
    'singular' => 'Comment',
    'plural' => 'Comments',
    'content' => 'content',
    'user_id' => 'user_id',
    'article_id' => 'article_id',
];
