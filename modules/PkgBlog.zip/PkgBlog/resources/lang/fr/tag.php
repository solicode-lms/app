<?php
// Ce fichier est maintenu par ESSARRAJ Fouad


return [
    'singular' => 'Tag',
    'plural' => 'Tags',
    'name' => 'name',
    'slug' => 'slug',
];
